package com.example.papercrunch;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
DatabaseHelper myDb;
EditText edit_username;
EditText edit_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);
        edit_username=(EditText)findViewById(R.id.editText7);
        edit_password=(EditText)findViewById(R.id.editText6);
    }
    public void Register(View view)
    {
       boolean isinserted = myDb.insertData(edit_username.getText().toString(),edit_password.getText().toString());
       if(isinserted =true)
           Toast.makeText(MainActivity.this,"Data Inserted",Toast.LENGTH_LONG).show();
       else
           Toast.makeText(MainActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();

    }
}
